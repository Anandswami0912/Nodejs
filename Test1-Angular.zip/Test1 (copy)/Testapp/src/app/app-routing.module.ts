import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HeaderComponent } from './header/header.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
{
    path: '',
    component: LoginComponent,
},
{
  path: 'login',
  component: LoginComponent,
},
{
  path: 'sidebar',
  component: SidebarComponent,
},
{
  path: 'header',
  component:HeaderComponent,
},
{
  path: 'dashboard',
  component:DashboardComponent,
},
{
  path: '**',
  component: PagenotfoundComponent,
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
